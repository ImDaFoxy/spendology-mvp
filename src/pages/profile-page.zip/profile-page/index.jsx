import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './profile.css';

export const Profile = () => {
    const [fileUrl, setFileUrl] = useState(null);
    return (
        <div class="container">
            <div class="main">
                <div class="topbar">
                    <a href="">Log Out</a> <b></b>
                    <a href="">Expense Tracker</a>
                </div>
                <div class="row">
                    <div class="col-md-4 mt-1">
                        <div class="card text-center sidebar">
                        <div class="card-body">
                            <img src="./user.png" class="rounded-circle" width="150"></img>
                            <div class="mt-3">
                                <h3>Firstname Lastname</h3>
                                <a href="">Expense Tracker</a> <b></b>
                                <a href="">Settings</a> <b></b>
                                <a href="">Log Out</a>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-8 mt-1">
                        <div class="card md-3 content">
                        <h1 class="m-3 pt-3">About</h1>
                        <div class="card body">
                            <br></br>
                            <div class="row">
                                <div class="col-md-3">
                                    <h5>Full Name</h5>
                                    <h5>Username</h5>
                                    <h5>Email</h5>
                                </div>
                                <div class="col-md-9">
                                    <p class="text-secondary">Firstname Lastname</p>
                                    <p class="text-secondary">name123</p>
                                    <p class="text-secondary">name@gmail.com</p>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Profile;
